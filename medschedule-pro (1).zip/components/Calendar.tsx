import React, { useState, useMemo } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface CalendarProps {
  selectedDate: Date;
  onDateSelect: (date: Date) => void;
}

const Calendar: React.FC<CalendarProps> = ({ selectedDate, onDateSelect }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  
  // Helper to normalize date for comparison (ignore time)
  const isSameDay = (d1: Date, d2: Date) => {
    return d1.getDate() === d2.getDate() &&
           d1.getMonth() === d2.getMonth() &&
           d1.getFullYear() === d2.getFullYear();
  };

  const isBeforeToday = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return date < today;
  };

  const calendarData = useMemo(() => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    
    const daysInMonth = lastDay.getDate();
    const startDayOfWeek = firstDay.getDay(); // 0 = Sunday
    
    const days = [];
    
    // Empty slots for days before start of month
    for (let i = 0; i < startDayOfWeek; i++) {
      days.push(null);
    }
    
    // Actual days
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(new Date(year, month, i));
    }

    return days;
  }, [currentMonth]);

  const handlePrevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1));
  };

  const monthNames = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
  const weekDays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

  return (
    <div className="bg-white rounded-3xl p-6 shadow-xl w-full max-w-md mx-auto lg:mx-0">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-primary">
          {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
        </h2>
        <div className="flex gap-2">
          <button 
            onClick={handlePrevMonth}
            className="w-10 h-10 flex items-center justify-center rounded-xl bg-gradient-to-br from-primary to-primary-light text-white hover:scale-105 transition-transform"
          >
            <ChevronLeft size={20} />
          </button>
          <button 
            onClick={handleNextMonth}
            className="w-10 h-10 flex items-center justify-center rounded-xl bg-gradient-to-br from-primary to-primary-light text-white hover:scale-105 transition-transform"
          >
            <ChevronRight size={20} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-2 mb-2">
        {weekDays.map(day => (
          <div key={day} className="text-center text-xs font-semibold text-gray-400 py-2 uppercase tracking-wide">
            {day}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-2">
        {calendarData.map((date, index) => {
          if (!date) {
            return <div key={`empty-${index}`} className="aspect-square" />;
          }

          const isDisabled = isBeforeToday(date);
          const isSelected = isSameDay(date, selectedDate);
          const isToday = isSameDay(date, new Date());

          let className = "aspect-square flex items-center justify-center rounded-xl text-sm font-medium transition-all duration-300 relative ";
          
          if (isDisabled) {
            className += "text-gray-300 cursor-not-allowed bg-gray-50";
          } else if (isSelected) {
            className += "bg-gradient-to-br from-primary to-primary-light text-white shadow-lg scale-105 font-bold cursor-default";
          } else if (isToday) {
            className += "bg-blue-50 text-primary border-2 border-blue-100 hover:border-primary cursor-pointer font-bold";
          } else {
            className += "text-gray-700 hover:bg-blue-50 hover:text-primary cursor-pointer";
          }

          return (
            <button
              key={date.toISOString()}
              disabled={isDisabled}
              onClick={() => onDateSelect(date)}
              className={className}
            >
              {date.getDate()}
              {/* Optional dot indicator for appointments could go here */}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default Calendar;
